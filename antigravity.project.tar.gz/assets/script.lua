--[[
    Client Instrumentation & Movement Suite (Executor Environment Compatible)
    Target: Roblox Luau Engine / Standard Execution Contexts
    Protection: Isolated Container (gethui / CoreGui) — Zero Character Pollution
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local CoreGui = game:GetService("CoreGui")

local LocalPlayer = Players.LocalPlayer
local Camera = workspace.CurrentCamera

-- Resolve safe container to avoid Character.DescendantAdded detection
local SafeContainer = nil
if typeof(gethui) == "function" then
    SafeContainer = gethui()
else
    local success, _ = pcall(function() return CoreGui:GetChildren() end)
    if success then
        SafeContainer = CoreGui
    else
        SafeContainer = LocalPlayer:WaitForChild("PlayerGui")
    end
end

-- Configuration
local Config = {
    Flight = {
        Enabled = false,
        Speed = 60,
        VerticalSpeed = 40,
        Key = Enum.KeyCode.X
    },
    Visuals = {
        Enabled = true,
        FillColor = Color3.fromRGB(0, 255, 140),
        OutlineColor = Color3.fromRGB(255, 255, 255),
        FillTransparency = 0.6,
        OutlineTransparency = 0.1
    },
    Teleport = {
        ClickTPKey = Enum.KeyCode.T,
        SmoothInterpolation = true,
        SpeedThreshold = 220
    }
}

-- Movement / Flight Engine State
local FlightState = {
    Active = false,
    Forward = 0,
    Backward = 0,
    Left = 0,
    Right = 0,
    Up = 0,
    Down = 0,
    BodyGyro = nil,
    BodyVelocity = nil
}

local function GetRoot(character)
    if not character then return nil end
    return character:FindFirstChild("HumanoidRootPart") or character:FindFirstChild("Torso")
end

local function GetHumanoid(character)
    if not character then return nil end
    return character:FindFirstChildOfClass("Humanoid")
end

local function ToggleFlight()
    local char = LocalPlayer.Character
    local root = GetRoot(char)
    local hum = GetHumanoid(char)
    if not root or not hum then return end

    FlightState.Active = not FlightState.Active

    if FlightState.Active then
        local bg = Instance.new("BodyGyro")
        bg.P = 9e4
        bg.MaxTorque = Vector3.new(9e9, 9e9, 9e9)
        bg.CFrame = root.CFrame
        bg.Name = "FlightGyro"
        bg.Parent = root
        FlightState.BodyGyro = bg

        local bv = Instance.new("BodyVelocity")
        bv.Velocity = Vector3.zero
        bv.MaxForce = Vector3.new(9e9, 9e9, 9e9)
        bv.Name = "FlightVelocity"
        bv.Parent = root
        FlightState.BodyVelocity = bv

        hum.PlatformStand = true
    else
        if FlightState.BodyGyro then
            FlightState.BodyGyro:Destroy()
            FlightState.BodyGyro = nil
        end
        if FlightState.BodyVelocity then
            FlightState.BodyVelocity:Destroy()
            FlightState.BodyVelocity = nil
        end
        hum.PlatformStand = false
    end
end

-- Flight Movement Loop
RunService.RenderStepped:Connect(function()
    if not FlightState.Active then return end
    local char = LocalPlayer.Character
    local root = GetRoot(char)
    if not root or not FlightState.BodyGyro or not FlightState.BodyVelocity then return end

    FlightState.BodyGyro.CFrame = Camera.CFrame

    local moveDir = Vector3.new(
        FlightState.Right - FlightState.Left,
        FlightState.Up - FlightState.Down,
        FlightState.Backward - FlightState.Forward
    )

    if moveDir.Magnitude > 0 then
        local camCF = Camera.CFrame
        local targetVelocity = (camCF.RightVector * (FlightState.Right - FlightState.Left) * Config.Flight.Speed)
            + (Vector3.new(0, 1, 0) * (FlightState.Up - FlightState.Down) * Config.Flight.VerticalSpeed)
            + (camCF.LookVector * (FlightState.Forward - FlightState.Backward) * Config.Flight.Speed)
        FlightState.BodyVelocity.Velocity = targetVelocity
    else
        FlightState.BodyVelocity.Velocity = Vector3.zero
    end
end)

-- Keybind Processing
UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if gameProcessed then return end

    if input.KeyCode == Config.Flight.Key then
        ToggleFlight()
    elseif input.KeyCode == Enum.KeyCode.W then
        FlightState.Forward = 1
    elseif input.KeyCode == Enum.KeyCode.S then
        FlightState.Backward = 1
    elseif input.KeyCode == Enum.KeyCode.A then
        FlightState.Left = 1
    elseif input.KeyCode == Enum.KeyCode.D then
        FlightState.Right = 1
    elseif input.KeyCode == Enum.KeyCode.Space then
        FlightState.Up = 1
    elseif input.KeyCode == Enum.KeyCode.LeftControl then
        FlightState.Down = 1
    elseif input.KeyCode == Config.Teleport.ClickTPKey then
        local mouse = LocalPlayer:GetMouse()
        if mouse and mouse.Hit then
            local char = LocalPlayer.Character
            local root = GetRoot(char)
            if root then
                local targetCF = CFrame.new(mouse.Hit.Position + Vector3.new(0, 3, 0))
                if Config.Teleport.SmoothInterpolation then
                    local startCF = root.CFrame
                    local distance = (targetCF.Position - startCF.Position).Magnitude
                    local duration = math.clamp(distance / Config.Teleport.SpeedThreshold, 0.04, 0.35)
                    local tweenInfo = TweenInfo.new(duration, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
                    local tween = TweenService:Create(root, tweenInfo, {CFrame = targetCF})
                    tween:Play()
                else
                    root.CFrame = targetCF
                end
            end
        end
    end
end)

UserInputService.InputEnded:Connect(function(input)
    if input.KeyCode == Enum.KeyCode.W then
        FlightState.Forward = 0
    elseif input.KeyCode == Enum.KeyCode.S then
        FlightState.Backward = 0
    elseif input.KeyCode == Enum.KeyCode.A then
        FlightState.Left = 0
    elseif input.KeyCode == Enum.KeyCode.D then
        FlightState.Right = 0
    elseif input.KeyCode == Enum.KeyCode.Space then
        FlightState.Up = 0
    elseif input.KeyCode == Enum.KeyCode.LeftControl then
        FlightState.Down = 0
    end
end)

-- Visual Marker Pipeline (Isolated from Character Descendants)
local ActiveVisuals = {}

local function CleanupVisual(player)
    if ActiveVisuals[player] then
        pcall(function()
            if ActiveVisuals[player].Highlight then ActiveVisuals[player].Highlight:Destroy() end
            if ActiveVisuals[player].Tag then ActiveVisuals[player].Tag:Destroy() end
        end)
        ActiveVisuals[player] = nil
    end
end

local function AttachVisuals(player)
    if player == LocalPlayer then return end

    local function ApplyToCharacter(character)
        CleanupVisual(player)
        if not character then return end
        local root = character:WaitForChild("HumanoidRootPart", 5)
        if not root then return end

        -- Highlight parented to SafeContainer instead of character to avoid descendant scans
        local highlight = Instance.new("Highlight")
        highlight.Name = "Node_" .. player.Name
        highlight.FillColor = Config.Visuals.FillColor
        highlight.OutlineColor = Config.Visuals.OutlineColor
        highlight.FillTransparency = Config.Visuals.FillTransparency
        highlight.OutlineTransparency = Config.Visuals.OutlineTransparency
        highlight.Adornee = character
        highlight.Enabled = Config.Visuals.Enabled
        highlight.Parent = SafeContainer

        -- BillboardGui also isolated in SafeContainer
        local tag = Instance.new("BillboardGui")
        tag.Name = "Tag_" .. player.Name
        tag.Size = UDim2.new(0, 130, 0, 35)
        tag.StudsOffset = Vector3.new(0, 3.2, 0)
        tag.AlwaysOnTop = true
        tag.Adornee = root
        tag.Enabled = Config.Visuals.Enabled

        local label = Instance.new("TextLabel")
        label.Size = UDim2.new(1, 0, 1, 0)
        label.BackgroundTransparency = 1
        label.TextColor3 = Color3.fromRGB(255, 255, 255)
        label.TextStrokeTransparency = 0.3
        label.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
        label.Font = Enum.Font.SourceSansBold
        label.TextSize = 13
        label.Parent = tag

        tag.Parent = SafeContainer
        ActiveVisuals[player] = {Highlight = highlight, Tag = tag, Label = label}
    end

    if player.Character then
        ApplyToCharacter(player.Character)
    end
    player.CharacterAdded:Connect(ApplyToCharacter)
end

for _, player in ipairs(Players:GetPlayers()) do
    AttachVisuals(player)
end

Players.PlayerAdded:Connect(AttachVisuals)
Players.PlayerRemoving:Connect(CleanupVisual)

-- Distance & Stat Update Loop
RunService.RenderStepped:Connect(function()
    if not Config.Visuals.Enabled then return end
    local localRoot = GetRoot(LocalPlayer.Character)

    for player, data in pairs(ActiveVisuals) do
        local char = player.Character
        local root = GetRoot(char)
        if root and localRoot and data.Label then
            local dist = math.floor((root.Position - localRoot.Position).Magnitude)
            local hum = GetHumanoid(char)
            local hp = hum and math.floor(hum.Health) or 0
            data.Label.Text = string.format("%s\n[%d studs | %d HP]", player.DisplayName, dist, hp)
        end
    end
end)

print("[Instrumentation Suite] Execution environment initialized cleanly.")
