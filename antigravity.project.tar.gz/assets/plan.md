# Porting Plan: Çaycık Boss Savaşı (Tkinter -> Pygame-CE / Mobile)

## 1. Engine & Porting Strategy
- **Target Engine:** `pygame-ce` (Python 3.14.8 environment already has `pygame-ce 2.5.8` installed).
- **Architecture:**
  - Screen resolution: Logical 960x540 viewport with letterboxing / aspect ratio scaling.
  - Geometry / Canvas conversion: Replace `tkinter.Canvas` primitive calls (`create_oval`, `create_polygon`, `create_line`, `create_rectangle`, `create_text`) with Pygame drawing routines (`pygame.draw.polygon`, `pygame.draw.ellipse`, `pygame.draw.line`, `pygame.draw.rect`, and font rendering).
  - Virtual Touch Controls:
    - Left stick / D-Pad: Move Left, Right, Aim Up.
    - Right buttons: Jump / Parry, Shoot (autofire toggle or hold), Dash, EX.
    - Top buttons: Pause, Settings.
  - Sound: Pygame mixer procedural sound generator (converting the wave synth to pygame Sound objects).
  - Persistence: JSON file saved locally (`caycik_kayit.json`).

## 2. Deliverables
1. `main.py`: Fully functional Pygame-CE standalone game with touch UI and keyboard fallback.
2. `buildozer.spec`: Configuration file for Android APK packaging.
3. GitHub Actions workflow (`.github/workflows/build_apk.yml`): Automated workflow to build the Android APK via cloud Linux runner without needing local WSL/Linux setup.
